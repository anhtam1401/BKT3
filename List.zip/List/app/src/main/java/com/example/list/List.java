package com.example.list;

import androidx.fragment.app.Fragment;

public class List extends Fragment {
}
